from django.apps import AppConfig


class PtAuthConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'pt_auth'
